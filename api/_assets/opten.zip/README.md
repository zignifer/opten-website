# Opten (private skill)

Локальный skill-бандл, который превращает Claude Desktop / Claude Code / Custom GPT в улучшалку промптов для AI-генераторов (image + video). Использует публичный endpoint Opten-прокси, отдающий .md правила по имени модели.

> Этот пакет распространяется вручную Pro-пользователям. Не коммитить в публичные репозитории.

## Что внутри

- `SKILL.md` — инструкция для AI-агента (что делать при триггер-фразе).
- `README.md` — этот файл.

## Триггер-фразы

Skill активируется на **любое** упоминание `оптен` (в любом падеже: оптен/оптена/оптеном/оптену) или `opten` вместе с моделью и промптом. Точная формулировка не важна — главное, чтобы было ясно «улучши промпт для такой-то модели».

**Канонические формы (короткие):**

| Команда | Что делает |
|---|---|
| `оптен <модель> <промпт>` | Улучшает промпт по правилам модели |
| `opten <model> <prompt>` | То же, EN |
| `оптен список` / `opten list` | Показывает каталог моделей |

**Натуральные варианты (тоже работают):**

- `сделай промпт оптеном для flux: cat on a sofa`
- `улучши через оптен midjourney-7: woman in red dress`
- `с помощью оптена для kling-3: девушка на пляже`
- `прогони через опнет sora-2: ...` (опечатка — тоже распознаётся)
- `use opten on flux: photo of a fox`
- `run opten for kling-3 <prompt>`
- `какие модели поддерживает оптен?` → каталог

Главное — чтобы в сообщении было слово `оптен`/`opten` + имя модели + текст промпта (или запрос каталога).

Пример: `оптен kling-3 девушка идёт по пляжу на закате` → агент вернёт улучшенный промпт по правилам Kling 3.

## Установка

### Claude Desktop (macOS/Windows)

1. Открой Claude Desktop → Settings → Skills (если фича доступна в твоей версии).
2. Жми **Add skill** → **Import from folder** → выбери папку `opten/` (или загрузи `opten.zip`).
3. После загрузки — пиши в новом чате `оптен <модель> <промпт>`.

Если в твоей версии Claude Desktop ещё нет UI для skills — используй вариант с Claude Code (ниже).

### Claude Code (CLI)

1. Скопируй `opten/` в `~/.claude/skills/opten/` (Linux/macOS) или `%USERPROFILE%\.claude\skills\opten\` (Windows).
2. Перезапусти Claude Code или открой новый сеанс.
3. Триггер-фраза работает в любом проекте.

### Любой другой LLM с web-fetch

Скопируй содержимое `SKILL.md` в system prompt. Главное требование — у модели должен быть инструмент для HTTP GET (browsing / web fetch / tool use).

## Endpoint

Skill дёргает публичный endpoint Opten-прокси:

- `GET https://promptscore-proxy.vercel.app/api/skill?model=<name>` → `text/markdown` с правилами для модели
- `GET https://promptscore-proxy.vercel.app/api/skill?list=1` → JSON `{ count, models: [...] }`

Endpoint без авторизации, IP-rate-limit 20 req/min. Если упёрся в лимит — подожди минуту.

## Доступные модели

Актуальный список — `оптен список` или `curl https://promptscore-proxy.vercel.app/api/skill?list=1`. На момент написания: ~60 моделей (flux*, kling*, midjourney*, sora-2, veo*, luma*, runway*, seedance*, и т.д.).

## Privacy

Skill отправляет твой промпт **только в Claude**. Opten-прокси видит только имя модели, не сам промпт — он отдаёт статический .md файл и всё. Логи прокси содержат IP + имя модели + timestamp (для rate-limit), не более.

## Отключение

Удали папку `opten/` из `~/.claude/skills/`. Никаких остаточных хвостов в системе нет.
